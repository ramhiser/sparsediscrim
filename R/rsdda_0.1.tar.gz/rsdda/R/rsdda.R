rsdda <-
function(training.df, num.alphas = 5, jointdiag = "none", verbose = FALSE, ...) {
	rsdda.obj <- list()
	rsdda.obj$training <- training.df
	
	if(jointdiag != "none") {
		if(verbose) cat("Simultaneously diagonalizing covariance matrices\n")
		joint.diag.out <- joint.diagonalization(rsdda.obj$training, method = jointdiag)
		rsdda.obj$training <- joint.diag.out$transformed.df
		rsdda.obj$jointdiag.B <- joint.diag.out$B
		rsdda.obj$jointdiag.method <- joint.diag.out$method
		if(verbose) cat("Simultaneously diagonalizing covariance matrices...done!\n")
	}

	if(verbose) cat("Building RSDDA classifier\n")
	N <- nrow(rsdda.obj$training)
	num.classes <- nlevels(rsdda.obj$training$labels)
	
	training.x <- as.matrix(rsdda.obj$training[,-1])
	dimnames(training.x) <- NULL
	
	estimators <- dlply(rsdda.obj$training, .(labels), function(class.df) {
		class.x <- as.matrix(class.df[, -1])
		dimnames(class.x) <- NULL
		
		n.k <- nrow(class.x)
		p.hat <- n.k / N
		
		xbar <- as.vector(colMeans(class.x))
		
		sum.squares <- apply(class.x, 2, function(col) {
			(n.k - 1) * var(col)
		})
		
		var <- apply(class.x, 2, function(col) {
			(n.k - 1) * var(col) / n.k
		})
		
		var.shrink <- var.shrinkage(N = n.k, K = 1, var.feature = var, num.alphas = num.alphas, t = -1)
		
		list(xbar = xbar, var.k = var.shrink, sum.squares = sum.squares, n = n.k, p.hat = p.hat)
	})
	
	var.pooled <- colSums(laply(estimators, function(class.est) class.est$sum.squares)) / N
	var.pool.shrink <- var.shrinkage(N = N, K = num.classes, var.feature = var.pooled, num.alphas = num.alphas, t = -1)
	
	estimators <- llply(estimators, function(class.estimators) {
		class.estimators$var.pool <- var.pool.shrink
		class.estimators
	})
	
	if(verbose) cat("Building RSDDA classifier...done!\n")
	
	rsdda.obj$N <- N
	rsdda.obj$classes <- levels(rsdda.obj$training$labels)
	rsdda.obj$estimators <- estimators
	
	class(rsdda.obj) <- "rsdda"

	rsdda.obj
}

