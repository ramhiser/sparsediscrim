h <-
function(nu, p, t = -1) {
	(nu / 2)^t * (gamma(nu / 2) / gamma(nu / 2 + t / p))^p
}

