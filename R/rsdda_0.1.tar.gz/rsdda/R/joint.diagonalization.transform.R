joint.diagonalization.transform <-
function(df, B) {
	transformed.df <- ddply(df, .(labels), function(class.df) {
		x <- as.matrix(class.df[,-1])
		dimnames(x) <- NULL
		data.frame(x %*% t(B))
	})
	transformed.df
}

