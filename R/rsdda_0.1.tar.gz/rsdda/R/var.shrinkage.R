var.shrinkage <-
function(N, K, var.feature, num.alphas = 2, t = -1) {
	nu <- N - K
	p <- length(var.feature)
	
	risk.stein.out <- risk.stein(N = N, K = K, var.feature = var.feature, num.alphas = num.alphas, t = t)

	var.pooled <- risk.stein.out$var.pooled
	alpha <- risk.stein.out$alpha
	
	var.feature.shrink <- (h(nu = nu, p = p, t = t) * var.pooled)^alpha * (h(nu = nu, p = 1, t = t) * var.feature)^(1 - alpha)
	var.feature.shrink
}

