dqda <-
function(training.df, jointdiag = "none", verbose = FALSE, ...) {
	dqda.obj <- list()
	dqda.obj$training <- training.df
	
	if(jointdiag != "none") {
		if(verbose) cat("Simultaneously diagonalizing covariance matrices\n")
		joint.diag.out <- joint.diagonalization(dqda.obj$training, method = jointdiag)
		dqda.obj$training <- joint.diag.out$transformed.df
		dqda.obj$jointdiag.B <- joint.diag.out$B
		dqda.obj$jointdiag.method <- joint.diag.out$method
		if(verbose) cat("Simultaneously diagonalizing covariance matrices...done!\n")
	}
	
	if(verbose) cat("Building DQDA classifier\n")
	N <- nrow(dqda.obj$training)
	
	estimators <- dlply(dqda.obj$training, .(labels), function(class.df) {
		n.k <- nrow(class.df)
		p.hat <- n.k / N
		xbar <- as.vector(colMeans(class.df[, -1]))
		var <- apply(class.df[,-1], 2, function(col) {
			(n.k - 1) * var(col) / n.k
		})
		list(xbar = xbar, var = var, n = n.k, p.hat = p.hat)
	})
	
	if(verbose) cat("Building DQDA classifier...done!\n")
	
	dqda.obj$N <- N
	dqda.obj$classes <- levels(dqda.obj$training$labels)
	dqda.obj$estimators <- estimators
	
	class(dqda.obj) <- "dqda"
	
	dqda.obj
}

