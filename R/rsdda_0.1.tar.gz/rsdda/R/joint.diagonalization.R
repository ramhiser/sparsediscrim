joint.diagonalization <-
function(df, method = c("none", "general-eigen", "asfari", "jade", "jedi", "qdiag", "ffdiag", "jadiag", "uwedge"),
	tol = 1e-6, max.iter = 250, shrink = TRUE, shrink.val = 0.01) {

	method <- match.arg(method)
	if(method == "none") {
		B <- diag(ncol(df) - 1)
	} else if(method == "general-eigen") {
		warning("Generalized Eigenvalues has not been implemented yet.")
	} else if(method == "asfari") {
		asfari.cov <- asfari.cov(df, shrink = TRUE, shrink.val = shrink.val)
		B <- LUJID(asfari.cov, mode = 'B', ERR = tol, RBALANCE = 3, ITER = max.iter)
		df <- joint.diagonalization.transform(df, B)
	} else if(method == "jade") {
		warning("JADE algorithm has not been implemented yet.")
		B <- diag(ncol(df) - 1)
	} else if(method == "jedi") {
		ajd.cov <- jointDiag.cov(df, shrink = TRUE, shrink.val = shrink.val)
		B <- jedi(ajd.cov, eps = tol, itermax = max.iter)$A
		df <- joint.diagonalization.transform(df, B)
	} else {
		ajd.cov <- jointDiag.cov(df, shrink = TRUE, shrink.val = shrink.val)
		B <- ajd(ajd.cov, method = method, eps = tol, itermax = max.iter)$B
		df <- joint.diagonalization.transform(df, B)
	}
	list(transformed.df = df, B = B, method = method)
}

