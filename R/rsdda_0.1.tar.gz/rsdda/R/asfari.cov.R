asfari.cov <-
function(df, shrink = FALSE, shrink.val = 0.01) {
	if(shrink == FALSE) {
		shrink.val <- 0
	}
	covs <- dlply(df, .(labels), function(class.df) {
		n.k <- nrow(class.df)
		p <- ncol(class.df) - 1
		(1 - shrink.val) * (n.k - 1) * cov(class.df[,-1]) / n.k + shrink.val * diag(p)
	})
	covs.cbind <- do.call("cbind", covs)
	dimnames(covs.cbind) <- NULL
	covs.cbind
}

